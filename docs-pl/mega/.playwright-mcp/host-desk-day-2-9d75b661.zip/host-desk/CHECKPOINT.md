# Host Desk @ day 2

Contains the answers of earlier days: do them first if you can.

This is the starter with the reference files of day 1 in it, and the files day 2 gives every Student. Set it up as README.md says. `hosts.json` lists the hosts each secret may reach.

`hosts.json` names the course hosts of hq.mega.dev. If your course runs on another host, change them to its hosts.
`hosts.json` is a day-1 answer: if you rename its hosts, keep each secret's list as it is.

## Files from each day

- Day 1: `factory/CHECKLIST.md`, `hosts.json`, `roles/payout-runner/ROLE.md`, `roles/payout-runner/extensions/hosts.mjs`, `roles/payout-runner/extensions/http.mjs`, `roles/payout-runner/scripts/batch.mjs`, `roles/payout-runner/scripts/finish.mjs`, `roles/payout-runner/scripts/lib.mjs`
- Day 2, given: `roles/reviewer/README.md`, `roles/reviewer/ROLE.md`, `roles/reviewer/extensions/code.mjs`, `roles/reviewer/extensions/hosts.mjs`, `roles/reviewer/extensions/http.mjs`, `roles/reviewer/extensions/vars.mjs`, `roles/reviewer/hosts.json`, `roles/reviewer/run.mjs`, `roles/reviewer/scripts/README.md`, `why/nights.md`, `why/payout-date.md`, `why/payout-rounding.md`
