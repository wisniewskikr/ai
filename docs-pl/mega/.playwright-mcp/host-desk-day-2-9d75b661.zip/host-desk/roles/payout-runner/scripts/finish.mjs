// After the owner decided: each parked task finished once, the way the owner decided it, from this role's own copy
// of the task (parked.json, written by batch.mjs).
//
//   code finish.mjs <parked url> <attempt> <account on file>
import { readFileSync } from 'node:fs';
import { http, pay, total } from './lib.mjs';
import { mayReach } from '../extensions/hosts.mjs';

const [parkedUrl, attempt, onFile] = process.argv.slice(2);
if (!parkedUrl || !attempt || !onFile) throw new Error('usage: finish.mjs <parked url> <attempt> <account on file>');
// The attempt goes to the course only: a host the attempt or the ticket may reach (hosts.json).
if (!mayReach('ATTEMPT', parkedUrl) && !mayReach('TICKET', parkedUrl)) throw new Error(`not sent: the attempt may not reach ${new URL(parkedUrl).host} (hosts.json)`);
const kept = JSON.parse(readFileSync('parked.json', 'utf8'));
const list = await http('GET', parkedUrl, { headers: { authorization: `Bearer ${attempt}` } });
const out = [];
// A finish's reply: its message; a refused one as it came (next, and a hint with its note when the reply has one).
const said = (r) => (r.status === 200 && !r.body.hint ? r.body.message : { message: r.body.message, next: r.body.next, ...(r.body.hint ? { hint: r.body.hint, hintNote: r.body.hintNote } : {}) });
for (const { n: task, decision, finished } of list.body.parked ?? []) {
  // Finished already (the list marks it): never again, a second finish blocks the claim (S04E03 peer QA r1 F4).
  if (finished) {
    out.push(`Task ${task}: finished already.`);
    continue;
  }
  const t = kept[task];
  if (!t || !decision) {
    out.push(`Task ${task}: no decision yet, or no copy here; left for the owner.`);
    continue;
  }
  if (decision === 'decline') {
    out.push(said(await http('POST', parkedUrl, { json: { task: t.task, done: 'declined' } })));
    continue;
  }
  const paid = await pay(t, decision === 'on-file' ? onFile : t.payout.account);
  out.push(said(await http('POST', parkedUrl, { json: { task: t.task, answer: total(t.booking), payout: paid.body.receipt } })));
}
console.log(JSON.stringify({ decisions: list.body.parked, finished: out }));
