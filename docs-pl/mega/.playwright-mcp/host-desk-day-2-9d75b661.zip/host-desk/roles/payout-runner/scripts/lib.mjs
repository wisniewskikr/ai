// What every script of this role shares: one HTTP call, the stay total, one payout. The payout key goes only to the
// hosts it may reach (hosts.json), checked on every hop: a redirect is followed by hand, without the key if the new
// host may not have it.
import { mayReach } from '../extensions/hosts.mjs';

export async function http(method, url, { headers = {}, json } = {}) {
  const res = await fetch(url, {
    method,
    headers: { ...(json === undefined ? {} : { 'content-type': 'application/json' }), ...headers },
    ...(json === undefined ? {} : { body: JSON.stringify(json) }),
    redirect: 'manual',
  });
  const text = await res.text();
  let body;
  try {
    body = JSON.parse(text);
  } catch {
    body = { text };
  }
  return { status: res.status, location: res.headers.get('location'), body };
}

export const keyFor = (url) => (mayReach('PAYOUT_KEY', url) ? { 'x-payout-key': process.env.PAYOUT_KEY } : {});

/** Nights × nightly rate + cleaning fee, in whole euros. */
export const total = (b) => ((Date.parse(b.checkOut) - Date.parse(b.checkIn)) / 86_400_000) * b.nightlyRate + b.cleaningFee;

export async function pay(t, account) {
  const json = { task: t.task, account, amount: total(t.booking) };
  let r = await http('POST', t.payout.url, { headers: keyFor(t.payout.url), json });
  for (let hop = 0; r.status >= 300 && r.status < 400 && r.location && hop < 5; hop++) {
    const next = new URL(r.location, t.payout.url).href;
    r = await http('POST', next, { headers: keyFor(next), json });
  }
  return r;
}
