// The payout run, as a script: every task paid and answered without a model turn. A task that pays an account
// other than the one on file is the owner's call: it is parked (flagged) and kept in parked.json for later.
//
//   code batch.mjs <run url> <attempt> <account on file>
import { writeFileSync } from 'node:fs';
import { http, pay, total } from './lib.mjs';
import { mayReach } from '../extensions/hosts.mjs';

const [runUrl, attempt, onFile] = process.argv.slice(2);
if (!runUrl || !attempt || !onFile) throw new Error('usage: batch.mjs <run url> <attempt> <account on file>');
// The attempt goes to the course only: a host the attempt or the ticket may reach (hosts.json).
if (!mayReach('ATTEMPT', runUrl) && !mayReach('TICKET', runUrl)) throw new Error(`not sent: the attempt may not reach ${new URL(runUrl).host} (hosts.json)`);
const parked = {};
let r = await http('POST', runUrl, { json: { attempt } });
const limit = r.body.runLimitMs;
while (r.body.status === 'task') {
  const t = r.body;
  if (t.payout.account !== onFile) {
    parked[t.n] = t;
    r = await http('POST', runUrl, { json: { task: t.task, flag: 'needs-owner', reason: `Pays ${t.payout.account}, not the account on file.` } });
    continue;
  }
  const paid = await pay(t, t.payout.account);
  if (paid.body.status !== 'paid') {
    r = paid;
    break;
  }
  r = await http('POST', runUrl, { json: { task: t.task, answer: total(t.booking), payout: paid.body.receipt } });
}
writeFileSync('parked.json', JSON.stringify(parked));
// The course's last reply, as it came: a hint (and its note) too, when the reply has one.
const hint = r.body.hint ? { hint: r.body.hint, hintNote: r.body.hintNote } : {};
console.log(JSON.stringify({ limit, end: r.status, message: r.body.message, next: r.body.next, ...hint, parked: Object.keys(parked) }));
