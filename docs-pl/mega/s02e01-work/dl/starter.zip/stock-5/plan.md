| Area | Choice | Source (session id + time) |
|------|--------|----------------------------|
